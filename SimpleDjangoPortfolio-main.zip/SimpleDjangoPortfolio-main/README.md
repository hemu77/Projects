# SimpleDjangoPortfolio

This is a Simple Python Django Portolio.The portfolio is easy  just use "/admin"  to login into Django admin panel to change you personal info.

<h3> 
     
     
<div> <img src="https://github.com/tech-jamara/SimpleDjangoPortfolio/blob/main/mode.png?raw=true"  />


## Run these Commads
### Step 1
     pip install -r requirements.txt
### Step 2
     python manage.py migrate
     
### Step 4
     python manage.py createsuperuser
        
### Step 3
     python manage.py runserver

  













